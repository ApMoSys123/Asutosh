<?php
/*
* iTech Empires:  Export Data from MySQL to CSV Script
* Version: 1.0.0
* Page: Export
*/
// Database Connection
require("db_connection.php");

// get Client List
$query = "SELECT * FROM project_list";
if (!$result = mysqli_query($con, $query)) {
    exit(mysqli_error($con));
}

$project_list = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $project_list[] = $row;
    }
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=projectdetails.csv');
$output = fopen('php://output', 'w');
fputcsv($output, array('id', 'name', 'type','client', 'RM ApMoSys','RM Client', 'department', 'status', 'date_created', 'start_date', 'end_date', 'rmclient_contact', 'rmclient_email'));

if (count($project_list) > 0) {
    foreach ($project_list as $row) {
        fputcsv($output, $row);
    }
}
?>
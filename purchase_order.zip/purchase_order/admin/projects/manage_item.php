<?php
require_once('../../config.php');
if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT * from `project_list` where id = '{$_GET['id']}' ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=stripslashes($v);
        }
    }
}
?>
<style>
    span.select2-selection.select2-selection--single {
        border-radius: 0;
        padding: 0.25rem 0.5rem;
        padding-top: 0.25rem;
        padding-right: 0.5rem;
        padding-bottom: 0.25rem;
        padding-left: 0.5rem;
        height: auto;
    }
</style>
<form action="" id="project-form">
     <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
    <div class="container-fluid">
        <div class="form-group">
            <label for="name" class="control-label">Project Name</label>
            <input type="text" name="name" id="name" class="form-control rounded-0" value="<?php echo isset($name) ? $name :"" ?>" required>
        </div>
        <div class="form-group">
			<label for="client">Client</label>
			<select name="client" id="client" class="custom-select custom-select-sm rounded-0 select2">
				<option value="" disabled <?php echo !isset($client) ? "selected" :'' ?>></option>
					<?php 
						$supplier_qry = $conn->query("SELECT * FROM `client_list` order by `name` asc");
						while($row = $supplier_qry->fetch_assoc()):
					?>
					<option value="<?php echo $row['name'] ?>" <?php echo isset($client_id) && $client_id == $row['name'] ? 'selected' : '' ?> <?php echo $row['status'] == 0? 'disabled' : '' ?>><?php echo $row['name'] ?></option>
					<?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="name" class="control-label">Start Date</label>
            <input type="text" name="startdate" id="startdate" class="form-control rounded-0" value="<?php echo isset($startdate) ? $startdate :"" ?>" required>
        </div>
        <div class="form-group">
            <label for="name" class="control-label">End Date</label>
            <input type="text" name="enddate" id="enddate" class="form-control rounded-0" value="<?php echo isset($enddate) ? $enddate :"" ?>" >
        </div>

        <div class="form-group">
            <label for="description" class="control-label">RM ApMoSys</label>
            <textarea rows="3" name="description" id="description" class="form-control rounded-0" required><?php echo isset($description) ? $description :"" ?></textarea>
        </div>
        <div class="form-group">
            <label for="rm_client" class="control-label">RM Client</label>
            <textarea rows="3" name="rm_client" id="rm_client" class="form-control rounded-0" required><?php echo isset($rm_client) ? $rm_client :"" ?></textarea>
        </div>
        <div class="form-group">
            <label for="department" class="control-label">Department</label>
            <textarea rows="3" name="department" id="department" class="form-control rounded-0" required><?php echo isset($department) ? $department :"" ?></textarea>
        </div>
        <div class="form-group">
            <label for="email" class="control-label">RM Client_Email</label>
            <input type="rmclient_email" name="rmclient_email" id="rmclient_email" class="form-control rounded-0" value="<?php echo isset($rmclient_email) ? $rmclient_email :"" ?>" required>
        </div>
        <div class="form-group">
            <label for="rmclient_contact" class="control-label">RM Client_Contact No.</label>
            <input type="rmclient_contact" name="rmclient_contact" id="rmclient_contact" class="form-control rounded-0" value="<?php echo isset($rmclient_contact) ? $rmclient_contact :"" ?>" required>
        </div>
        <div class="form-group">
            <label for="type" class="control-label">Project Type</label>
            <select name="type" id="type" class="form-control rounded-0" required>
                <option value="TNM" <?php echo isset($type) && $type =="" ? "selected": "TNM" ?> >TNM</option>
                <option value="FC" <?php echo isset($type) && $type =="" ? "selected": "FC" ?>>FC</option>
            </select>
        </div>
        <div class="form-group">
            <label for="status" class="control-label">Status</label>
            <select name="status" id="status" class="form-control rounded-0" required>
                <option value="Started" <?php echo isset($status) && $status =="" ? "selected": "Started" ?> >Started</option>
                <option value="Issue" <?php echo isset($status) && $status =="" ? "selected": "Issue" ?>>Issue</option>
                <option value="In Progress" <?php echo isset($status) && $status =="" ? "selected": "In Progress" ?>>In Progress</option>
                <option value="On hold" <?php echo isset($status) && $status =="" ? "selected": "3" ?>>On hold</option>
                <option value="Completed" <?php echo isset($status) && $status =="" ? "selected": "4" ?>>Completed</option>
            </select>
        </div>
    </div>
</form>
<script>

    $(function(){
        $('#project-form').submit(function(e){
			e.preventDefault();
            var _this = $(this)
			 $('.err-msg').remove();
			start_loader();
			$.ajax({
				url:_base_url_+"classes/Master.php?f=save_project",
				data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
				error:err=>{
					console.log(err)
					alert_toast("An error occured",'error');
					end_loader();
				},
				success:function(resp){
					if(typeof resp =='object' && resp.status == 'success'){
						location.reload();
					}else if(resp.status == 'failed' && !!resp.msg){
                        var el = $('<div>')
                            el.addClass("alert alert-danger err-msg").text(resp.msg)
                            _this.prepend(el)
                            el.show('slow')
                            $("html, body").animate({ scrollTop: 0 }, "fast");
                    }else{
						alert_toast("An error occured",'error');
                        console.log(resp)
					}
                    end_loader()
				}
			})
		})
	})
</script>
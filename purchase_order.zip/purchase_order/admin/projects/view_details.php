<?php
require_once('../../config.php');
if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT * from `project_list` where id = '{$_GET['id']}' ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=stripslashes($v);
        }
    }
}
?>
<style>
    #uni_modal .modal-footer{
        display:none
    }
</style>
<div class="container fluid">
    <callout class="callout-primary">
        <dl class="row">
            <dt class="col-md-4">Project Name</dt>
            <dd class="col-md-8">: <?php echo $name ?></dd>
            <dt class="col-md-4">Client</dt>
            <dd class="col-md-8">: <?php echo $client ?></dd>
            <dt class="col-md-4">Start Date</dt>
            <dd class="col-md-8">: <?php echo $startdate ?></dd>
            <dt class="col-md-4">End Date</dt>
            <dd class="col-md-8">: <?php echo $enddate ?></dd>
            <!-- <dt class="col-md-4">Project Type</dt>
            <dd class="col-md-8">: <?php echo $type ?></dd> -->
            <dt class="col-md-4">RM ApMoSys</dt>
            <dd class="col-md-8">: <?php echo $description ?></dd>
            <dt class="col-md-4">RM Client</dt>
            <dd class="col-md-8">: <?php echo $rm_client ?></dd>
            <dt class="col-md-4">Department</dt>
            <dd class="col-md-8">: <?php echo $department ?></dd>
            <dt class="col-md-4">RM Client_Contact</dt>
            <dd class="col-md-8">: <?php echo $rmclient_contact ?></dd>
            <dt class="col-md-4">RM Client_Email</dt>
            <dd class="col-md-8">: <?php echo $rmclient_email ?></dd>
            <dt class="col-md-4">Project Type</dt>
            <dd class="col-md-8">:&nbsp;
            <?php
							switch ($type) {
										
								case 'TNM':
									echo '<span class="badge badge-success">TNM</span>';
									break;
								case 'FC':
									echo '<span class="badge badge-secondary">FC</span>';
									break;
								}
							?>
            </dd>
            <dt class="col-md-4">Status</dt>
            <dd class="col-md-8">:&nbsp;
            <?php 
									switch ($status) {
										case 'Started':
											echo '<span class="badge badge-success">Started</span>';
											break;
										case 'Issue':
											echo '<span class="badge badge-danger">Issue</span>';
											break;
										case 'In Progress':
											echo '<span class="badge badge-secondary">In Progress</span>';
											break;
										case 'On hold':
												echo '<span class="badge badge-secondary">On hold</span>';
											break;
                                            case 'Completed':
											echo '<span class="badge badge-success">Completed</span>';
											break;

												
									}
								?>
            </dd>
        </dl>
    </callout>
    <div class="row px-2 justify-content-end">
        <div class="col-1">
            <button class="btn btn-dark btn-flat btn-sm" type="button" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
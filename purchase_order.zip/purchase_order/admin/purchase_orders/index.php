<?php if($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif;?>
<div class="card card-outline card-primary">
	<div class="card-header">
		<h3 class="card-title">List of Purchase Orders</h3>
		<div class="card-tools">
		<?php if($_settings->userdata('type') == 1): ?>
		<a href="?page=purchase_orders/manage_po" class="btn btn-flat btn-primary"><span class="fas fa-plus"></span>  Add New</a>
		<a href="http://localhost/purchase_order/admin/purchase_orders/export.php" class="btn btn-flat btn-success"><span class="fas fa-paper-plane"></span> Export</a>
			<?php endif; ?>
		</div>
	</div>
	<div class="card-body">
		<div class="container-fluid">
        <div class="container-fluid">
			<table class="table table-hover table-striped">
				<colgroup>
					<col width="5%">
					<col width="10%">
					<col width="10%">
					<col width="15%">
					<col width="10%">
					<col width="7%">
					<col width="10%">
					<col width="10%">
				</colgroup>
				<thead>
					<tr class="bg-navy disabled">
						<th>SNo.</th>
						<th class="text-center">Start Date</th>
						<th class="text-center">End Date</th>
						<th class="text-center">PO #</th>
						<th class="text-center">Client</th>
						<!-- <th class="text-center">Project</th> -->
						<th class="text-center">Project Type</th>
						<th class="text-center">Total Amount</th>
						<th class="text-center">PO Request</th>
						<th class="text-center">PO Status</th>
						<th class="text-center">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$i = 1;
						$qry = $conn->query("SELECT po.*, s.name as sname FROM `po_list` po inner join `client_list` s on po.client_id = s.id order by unix_timestamp(po.date_updated) ");
						while($row = $qry->fetch_assoc()):
							$row['item_count'] = $conn->query("SELECT * FROM order_items where po_id = '{$row['id']}'")->num_rows;
							$row['total_amount'] = $conn->query("SELECT sum(quantity * unit_price) as total FROM order_items where po_id = '{$row['id']}'")->fetch_array()['total'];
					?>
						<tr>
							<td class="text-center"><?php echo $i++; ?></td>
							<!-- <td class=""><?php echo date("M d,Y H:i",strtotime($row['date_created'])) ; ?></td> -->
							<td class="text-center"><?php echo $row['startdate'] ?></td>
							<td class="text-center"><?php echo $row['enddate'] ?></td>
							<td class="text-center"><?php echo $row['po_no'] ?></td>
							<td class="text-center"><?php echo $row['sname'] ?></td>
							<!-- <td class="text-center"><?php echo number_format($row['item_count']) ?></td> -->
							<td class="text-center">
							<?php
							switch ($row['type']) {
										
								case 'TNM':
									echo '<span class="badge badge-success">TNM</span>';
									break;
								case 'FC':
									echo '<span class="badge badge-secondary">FC</span>';
									break;
								}
							?>
							</td>

							<td class="text-center"><?php echo number_format($row['total_amount']) ?></td>
							<td class="text-center">
								<?php 
									switch ($row['request']) {
										case 'Approved':
											echo '<span class="badge badge-success">Approved</span>';
											break;
										case 'Denied':
											echo '<span class="badge badge-danger">Denied</span>';
											break;
										case 'Pending':
											echo '<span class="badge badge-secondary">Pending</span>';
											break;
									}
								?>
								<td class="text-center">
								<?php
							switch ($row['status']) {
										
								case 'Active':
									echo '<span class="badge badge-success">Active</span>';
									break;
								case 'Expire':
									echo '<span class="badge badge-danger">Expire</span>';
									break;
								}
							?>	
							</td>
							<td align="center">
								 <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
				                  		Action
				                    <span class="sr-only">Toggle Dropdown</span>
				                  </button>
				                  <div class="dropdown-menu" role="menu">
								  	<a class="dropdown-item" href="?page=purchase_orders/view_po&id=<?php echo $row['id'] ?>"><span class="fa fa-eye text-primary"></span> View</a>
				                    <div class="dropdown-divider"></div>
									
				                    <a class="dropdown-item" href="?page=purchase_orders/manage_po&id=<?php echo $row['id'] ?>"><span class="fa fa-edit text-primary"></span> Edit</a>
									<?php if($_settings->userdata('type') == 1): ?>
				                    <div class="dropdown-divider"></div>
				                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-trash text-danger"></span> Delete</a>
									<?php endif; ?>
				                  </div>
							</td>
						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
		</div>
	</div>
</div>
<script>
	
	$(document).ready(function(){
		$('.delete_data').click(function(){
			_conf("Are you sure to delete this PO permanently?","delete_rent",[$(this).attr('data-id')])
		})
		$('.view_details').click(function(){
			uni_modal("Reservaton Details","purchase_orders/view_details.php?id="+$(this).attr('data-id'),'mid-large')
		})
		$('.renew_data').click(function(){
			_conf("Are you sure to renew this  data?","renew_rent",[$(this).attr('data-id')]);
		})
		$('.table th,.table td').addClass('px-1 py-0 align-middle')
		$('.table').dataTable();
	})
	function delete_rent($id){
		start_loader();
		$.ajax({
			url:_base_url_+"classes/Master.php?f=delete_rent",
			method:"POST",
			data:{id: $id},
			dataType:"json",
			error:err=>{
				console.log(err)
				alert_toast("An error occured.",'error');
				end_loader();
			},
			success:function(resp){
				if(typeof resp== 'object' && resp.status == 'success'){
					location.reload();
				}else{
					alert_toast("An error occured.",'error');
					end_loader();
				}
			}
		})
	}
	function renew_rent($id){
		start_loader();
		$.ajax({
			url:_base_url_+"classes/Master.php?f=renew_rent",
			method:"POST",
			data:{id: $id},
			dataType:"json",
			error:err=>{
				console.log(err)
				alert_toast("An error occured.",'error');
				end_loader();
			},
			success:function(resp){
				if(typeof resp== 'object' && resp.status == 'success'){
					location.reload();
				}else{
					alert_toast("An error occured.",'error');
					end_loader();
				}
			}
		})
	}
</script>
<?php
/*
* iTech Empires:  Export Data from MySQL to CSV Script
* Version: 1.0.0
* Page: Export
*/
// Database Connection
require("db_connection.php");

// get Client List
$query = "SELECT * FROM po_list";
if (!$result = mysqli_query($con, $query)) {
    exit(mysqli_error($con));
}

$po_list = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $po_list[] = $row;
    }
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=podetails.csv');
$output = fopen('php://output', 'w');
fputcsv($output, array('id', 'po_no', 'client_id', 'tax_percentage', 'tax_amount', 'comments', 'request', 'status','date_created','date_updated','start_date', 'end_date', 'type'));

if (count($po_list) > 0) {
    foreach ($po_list as $row) {
        fputcsv($output, $row);
    }
}
?>